# Spin-Control Connectivity Graph: Ni₂/coronene benchmark

This release contains the analysis code and numerical records supporting the
retained-state study of spin-control connectivity descriptors for the fixed
geometry Ni₂/coronene model. It is a reproducibility archive for one
computational benchmark, not a general screening validation or a claim of
retained-state convergence.

Associated study: **Retained-State Selection Can Reverse Spin-Control Descriptor Correlations**, by Jing Liu, Kanchan Sarkar, and Axel Groß.

## Contents

- `analysis/sccg/`: graph and descriptor implementation, matrix-reconstruction
  audit, retained-state analyses, and tests.
- `calculations/B1/`: three parsed 45-state manifolds, descriptor sweeps,
  retained-state reconstruction arrays, and numerical sensitivity records.
- `figures/`: vector-PDF figures associated with the benchmark analyses.
- `pyproject.toml`, `uv.lock`, `.python-version`: the analysis environment.
- `CITATION.cff`, `.zenodo.json`, `LICENSE.md`, and `LICENSES/`: citation,
  release metadata, and licensing.

The reconstruction arrays are compact lossless exports of the Hamiltonian,
spin-free transition operators, and spin-orbit eigenvectors required for the
reported state-deletion analysis. Large quantum-chemistry scratch files and
full AO/density HDF5 outputs are not included. The archived parsed manifolds
and matrices are sufficient to reproduce the graph analysis; repeating the
electronic-structure calculations requires OpenMolcas and the calculation
inputs appropriate to the stated basis and active spaces. The included input
decks document the production, bridge, CASCI, XMS, and shift-scan settings;
starting orbital files and full AO/density HDF5 outputs are not distributed.

## Reproduce the numerical audit

Run from the repository root using Python 3.11 and
[`uv`](https://docs.astral.sh/uv/). Initial dependency installation requires
network access. The lockfile preserves the broader calculation environment;
not every dependency is needed for the graph audit.

```sh
uv sync --frozen --dev
uv run pytest
uv run python analysis/sccg/retained_state_audit.py
uv run python analysis/sccg/retained_state_robustness.py
uv run python analysis/sccg/verify_release.py
```

The retained-state programs write JSON and CSV records under `calculations/B1/` and may
replace the distributed copies. Run them in a disposable copy if you want to
preserve the original release records. Their calculations start from the
archived compact reconstruction arrays and do not rerun electronic structure.
The verification program checks all five descriptor sweeps against the archived
tables, all thirteen non-endpoint single-root deletions, and the support identity.
The graph and command-line defaults use dipole-only edges (`beta=0`), as in the
article. SOC is included through the SO eigenstates and transition dipoles, not
as an additional edge channel.

The release includes the evaluated descriptor sweeps and sensitivity outputs
as data. It does not claim that every distributed table or figure is regenerated
by the commands above. The tests exercise the graph implementation and the
independent matrix-reconstruction path.

## Scope and provenance

The production, compact MS-CASPT2 bridge, and compact CASCI model-space anchor
each contain 45 spin-orbit states. The compact and production active spaces are
not nested. Retained-root deletion calculations preserve the five-root
spin-free solutions and alter only the state-interaction construction; they
are stress tests, not convergence tests toward a larger state manifold.
Cross-tier rank correlations refer to photon-energy grid points within this
single system, not rankings of molecular candidates.

The source data were generated with OpenMolcas 24.02 and the archived analysis
environment is specified by the lockfile. `calculations/B1/manifest.yaml`
records the model and tier definitions. The SHA-256 manifest at the archive
root identifies the exact distributed files.
Selected electronic-structure output logs have filesystem paths redacted;
numerical energies, matrices, and printed state properties are unchanged.
Undefined correlations of constant curves are represented by JSON `null`, not
zero or nonstandard `NaN` values. The `boot95_lo` and `boot95_hi` fields in
`tier_correlations.json` are paired grid-point resampling percentiles, not
validated confidence intervals for correlated deterministic sweeps. They are
not used as uncertainty estimates in the associated study.
Input comments describe the scientific protocol; executable calculation
settings are preserved. Starting/restart orbital files named by those inputs
are not included. `calculations/B1/orbital_partition.json` records the production quintet
state-averaged occupations by file slot; these are not root-1 occupations.

## Integrity and citation

Verify the distributed files before running scripts that overwrite records:

```sh
sha256sum -c MANIFEST.sha256
```

Use `CITATION.cff` for the release title, authors, and version. The root
`.zenodo.json` supplies the Zenodo record metadata. The DOI and repository URL
are intentionally omitted until they exist; no example identifiers are used.

## Licensing

Numerical data and figures are made available under CC BY 4.0. The analysis
code is available under the MIT License; see `LICENSES/`.
